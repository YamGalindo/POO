package com.company;

// se genera usable como interfas por motivos de escalabilidad.

public interface Usable {

    public void Usable();
}
